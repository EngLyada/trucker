<?php

include_once "../connect.php"; // database connection details stored here

$user = $_SESSION['userid'] ;

$query=mysqli_query($con, "SELECT *  FROM `users` WHERE `userid` = '$user' ")or die(mysqli_error());
while($row = mysqli_fetch_assoc($query)) {
$level 	= $row['level'];
$img 	  = $row['user_image'];
$mail 	= $row['mail'];
$myname = $row['name'];
$branch = $row['dept'];
}

if ($img == ''){
	$image = 'umagi.jpg';
}else{
	$image = $img;
}

if(!isset($user)){
	?>
	<script>
		alert('Please Login to use this page');
		window.location.href='../login';
	</script>
<?php
}elseif($level  != 1 ){
?>
<script>
		alert('You are not authorised to view this page');
		window.location.href='../login';
</script>

<?php
}

echo '
<script type="text/javascript">
idleMax = 5;// Logout after 50 minutes of IDLE
idleTime = 0;
$(document).ready(function () {
    var idleInterval = setInterval("timerIncrement()", 500000);
    $(this).mousemove(function (e) {idleTime = 0;});
    $(this).keypress(function (e) {idleTime = 0;});
})
function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > idleMax) {
        window.location="../login";
    }
}
</script>';


?>


<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
    </li>
    <li class="nav-item">
      <form class="search-bar">
        <input type="text" class="form-control" placeholder="Enter keywords">
         <a href="javascript:void();"><i class="icon-magnifier"></i></a>
      </form>
    </li>
  </ul>
<h6 class="mt-2 user-title"><i class="fa fa-calendar"></i> <?php echo date("D, j F Y"); ?> | <?php echo $myname ?></h6>
  <ul class="navbar-nav align-items-center right-nav-link">
    <li class="nav-item dropdown-lg">

      <div class="dropdown-menu dropdown-menu-right">
        <ul class="list-group list-group-flush">



        </ul>
        </div>
    </li>
    <li class="nav-item dropdown-lg">

      <div class="dropdown-menu dropdown-menu-right">
        <ul class="list-group list-group-flush">

          <li class="list-group-item">

          </li>
          <li class="list-group-item">
          <a href="javaScript:void();">
           <div class="media">
             <i class="zmdi zmdi-coffee fa-2x mr-3 text-warning"></i>

          </div>
          </a>
          </li>
          <li class="list-group-item">
          <a href="javaScript:void();">
           <div class="media">
             <i class="zmdi zmdi-notifications-active fa-2x mr-3 text-danger"></i>

          </div>

        </ul>
      </div>
    </li>

    <li class="nav-item">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
        <span class="user-profile"><img src="../assets/images/<?php echo $image ?>" class="img-circle" alt="user avatar"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-right">
       <li class="dropdown-item user-details">
        <a href="javaScript:void();">
           <div class="media">
             <div class="avatar"><img class="align-self-start mr-3" src="../assets/images/<?php echo $image ?>" alt="user avatar"></div>





            <div class="media-body">
            <h6 class="mt-2 user-title"><?php echo $myname ?></h6>
            <p class="user-subtitle"><?php echo $mail ?></p>
            </div>
           </div>
          </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="#" <i class="icon-user"></i> Profile</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="changepassword" <i class="icon-settings"></i> Change Password</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="../logout" <i class="icon-power mr-2"></i> Logout</a></li>

      </ul>
    </li>
  </ul>
</nav>
</header>
<!--End topbar header-->
