<?php

include_once "../connect.php"; // database connection details stored here
include 'phpqrcode/qrlib.php';
$id=$_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Trucks</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

	<!--Data Tables -->
<link href="../assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="../assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

<!--Select Plugins-->
  <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet"/>
  <!--inputtags-->
  <link href="../assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />
  <!--multi select-->
  <link href="../assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
  <!--Bootstrap Datepicker-->
  <link href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
  <!--Touchspin-->
  <link href="../assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css">

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <!-- <h4 class="page-title">Track Vehicle Location </h4> -->

	   </div>
     </div>


		<div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><h3>Track Vehicle Location</h3></div>
            <div class="card-body">
              <div class="table-responsive">
                <form action="approve" method="post" name="form" id="form">

                        <br>
                      

                      <table id="example" class="table table-bordered">
                      <thead>
                      <tr>
                      <th>#</th>
                                     
                        <th>Truck No. Plate</th>
                        <th>Vehicle Model</th>
                        <th>Driver's Name</th>
                        <th>Organization</th>
                       
                        <th>Destination</th>
                        <th>Transporter Tel</th>
                        
                        <th>Supervisor</th>
                       
                        <th>Locate</th>
                    </tr>
                            </thead>
                            <tbody>
								 <?php
                  $i=0;
                  $query=mysqli_query($con, "SELECT *  FROM  transporter ORDER BY id DESC")or die(mysqli_error());
                  while($row=mysqli_fetch_array($query)){
                    $i=$i+1;
                  ?>
                  <tr>
                    <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $i; ?></a></td>
                      <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['ref']; ?></a></td>
                      <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['organization']; ?></a></td>
                  <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['t_name']; ?></a></td>
                  <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['origin']; ?></a></td>
                  <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['destn']; ?></a></td>
                  <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['t_tel']; ?> </a></td>
                  <td><a href="s_product?id=<?php echo $row['ref']; ?>"><?php echo $row['supervisor']; ?></a></td>           

                    
                  <td><a href="map?id=<?php echo $row['ref']; ?>"> <i class="fa fa-map"></i> </a></td>

                  </tr>
                  <?php } ?>
                            </tbody>
                        </table>
</form>
            </div>
<br>
<br>
<div class="card-header"><h3></h3></div>

            <div class="table-responsive">
              
          </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->

<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>
<?php  include_once("footer-data.php"); ?>
<script language="javascript">
    function printDiv(divName)
    {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents; window.print();
    document.body.innerHTML = originalContents;
    }
    </script>