<?php
  include_once "../connect.php"; // database connection details stored here

  $coordinates = array();
  $latitudes = array();
  $longitudes = array();

  // Select all the rows in the markers table
  $query = "SELECT  `latitude`, `longitude` FROM `test_results` ";
  $result = $con->query($query) or die('data selection for google map failed: ' . $mysqli->error);

  while ($row = mysqli_fetch_array($result)) {

    $latitudes[] = $row['latitude'];
    $longitudes[] = $row['longitude'];
    $coordinates[] = 'new google.maps.LatLng(' . $row['latitude'] .','. $row['longitude'] .'),';
  }

  //remove the comaa ',' from last coordinate
  $lastcount = count($coordinates)-1;
  $coordinates[$lastcount] = trim($coordinates[$lastcount], ","); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title> Truck Products</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/logo.png" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>
  <link href="../assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="../assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

</head>


<?php include_once("top-bar.php"); ?>
<?php include_once("sidebar.php"); ?>
<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Truck Products </h4>
     </div>
      <div class="col-sm-3" align="right">
        <form class="form-horizontal" action="" method="post" name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="form-area">       
              <button type="submit" id="submit" name="import" class="btn btn-primary">RELOAD DATA</button><br />
          </div>
              </form>
     </div>
     </div>
    <!-- End Breadcrumb-->
    <div class="row">
    <div class="col-lg-12">

     <div class="row">
        <div class="col-lg-12" style="height: 950px;">
          
             <div id="map" style="width: 100%; height: 80vh;"></div>
           
        </div>
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  </div>
</div>

<?php  include_once("footer.php"); ?>




    <script>
      function initMap() {
        var mapOptions = {
          zoom: 18,
          center: {<?php echo'lat:'. $latitudes[0] .', lng:'. $longitudes[0] ;?>}, //{lat: --- , lng: ....}
          mapTypeId: google.maps.MapTypeId.SATELITE
        };

        var map = new google.maps.Map(document.getElementById('map'),mapOptions);

        var RouteCoordinates = [
          <?php
            $i = 0;
          while ($i < count($coordinates)) {
            echo $coordinates[$i];
            $i++;
          }
          ?>
        ];

        var RoutePath = new google.maps.Polyline({
          path: RouteCoordinates,
          geodesic: true,
          strokeColor: '#1100FF',
          strokeOpacity: 1.0,
          strokeWeight: 10
        });

        mark = 'img/mark.png';
        flag = 'img/flag.png';

        startPoint = {<?php echo'lat:'. $latitudes[0] .', lng:'. $longitudes[0] ;?>};
        endPoint = {<?php echo'lat:'.$latitudes[$lastcount] .', lng:'. $longitudes[$lastcount] ;?>};

        var marker = new google.maps.Marker({
          position: startPoint,
          map: map,
          icon: mark,
          title:"Start point!",
          animation: google.maps.Animation.BOUNCE
        });

        var marker = new google.maps.Marker({
        position: endPoint,
         map: map,
         icon: flag,
         title:"End point!",
         animation: google.maps.Animation.DROP
      });

        RoutePath.setMap(map);
      }

      google.maps.event.addDomListener(window, 'load', initialize);
      </script>

      <!--remenber to put your google map key-->
      <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAvLTo_eC450KUGSV13GzwBLiGjhMt_PNY&callback=initMap"></script>
