<?php
// configuration
include_once('../connect.php');

// new data
$id = $_POST['memi'];
$a  = $_POST['name'];
$b  = $_POST['userid'];
$c  = $_POST['mail'];
$d  = $_POST['level'];
$e  = $_POST['salary'];

// query
$sql = "UPDATE users
        SET name=?, userid=?, mail=?, level=?, salary=?
		WHERE id=?";
$q = $dbo->prepare($sql);
$q->execute(array($a,$b,$c,$d,$e,$id));
header("location: signup");

?>
