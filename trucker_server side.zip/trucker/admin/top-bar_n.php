<?php

include_once "../connect.php"; // database connection details stored here

?>

<body class="bg-theme bg-theme1">

  <!-- start loader -->
  <!-- end loader -->

  <!-- Start wrapper-->
   <div id="wrapper">

    <!--Start sidebar-wrapper-->
     <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
       <div class="brand-logo">
        <a href="index.html">
         <img src="../assets/images/<?php echo $logo ?>" class="logo-icon" alt="logo icon">
         <h5 class="logo-text"><?php echo $name ?></h5>
       </a>
     </div>
