<?php

include_once "../connect.php"; // database connection details stored here

?>
<!DOCTYPE html>
<html>
<title>Testing</title>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>
<link rel="stylesheet" type="text/css"  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css"  href="https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css">
<script type="text/javascript">
$(document).ready(function () {
       $('#example').DataTable({
        columnDefs: [{
           orderable: false,
           className: 'select-checkbox',
                      targets: 0
           }],
            select: {
                style: 'multi',
                  selector: 'td:first-child'
                },
              order: [[1, 'asc']]
           });
    });
</script>
<body>

  <form action="pdt_save" method="post" name="form" id="form">

    <br>
  <button class="btn btn-success pull-right" name="submit_mult" type="submit">Add Selected</button>
  <table id="example" class="display" style="width:100%">
    <thead>
        <tr>
            <th><input id="check_all" class="formcontrol" type="checkbox"/></th>
            <th>Item Description</th>
            <th>Store Location</th>
            <th>Image</th>

        </tr>
    </thead>
    <tbody>
      <?php

      $query=mysqli_query($con, "SELECT *  FROM `product_list` ORDER BY sno DESC ")or die(mysqli_error());
      while($row=mysqli_fetch_array($query)){
          $id=$row['sno'];
      ?>
      <tr>
      <td><input name="selector[]" class="case" type="checkbox" value="<?php echo $id; ?>"></td>

      <td><?php echo $row['cat']. ' ' .$row['name']. ' ' .$row['brand']. ' ' .$row['vehicle']. ' ' .$row['engine']. ' ' .$row['chasis']. ' ' .$row['partNo'] ; ?></td>
      <td><?php echo $row['store_loc']?></td>
      <td>
        <?php

        $img = $row['user_image'];

        if ($row['user_image'] == ''){

          echo "<img src='../assets/images/umagi.jpg'  width='150'/> ";
        }
        else {

          echo "<img src='../assets/images/$img'  width='150' />";
        }

        ?>
      </td>
      </tr>
      <?php } ?>
    </tbody>

</table>
      </form>
</body>
</html>
