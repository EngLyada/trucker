<!DOCTYPE html>
<html>
<title>Pounds to Kilograms Weight Converter</title>
<script src="../assets/js/jquery.min.js"></script>
<body>
  <input type="number" name="notes" id="notes" value ="50" />
  <input type="number" name="qty" id="qty" />
  <input type="number" name="total" id="total" readonly />

<script>
$('#notes, #qty').keyup(function(){
    var notes = parseFloat($('#notes').val()) || 0;
    var qty = parseFloat($('#qty').val()) || 0;

    $('#total').val(notes * qty);
});
</script>

</body>
</html>
