<?php
// ../documentation/index.html
include_once('../connect.php');

				$result = $dbo->prepare("SELECT * FROM users ");
				$result->execute();
				$rowcount = $result->rowcount();
				//////// Generating next Invoice Number /////////
				?>

<ul class="sidebar-menu">
	 <li class="sidebar-header">MAIN NAVIGATION</li>

	 <li><a href="index" class="waves-effect"><i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span></a></li>

	<li><a href="trucks" class="waves-effect"><i class="zmdi zmdi-view-dashboard"></i> <span>Trucks</span></a></li>
	 <li>
		 <a href="" class="waves-effect">

			 <i class="zmdi zmdi-store"></i> <span> Medicine</span>

			 <i class="fa fa-angle-left pull-right"></i>
		 </a>
		 <ul class="sidebar-submenu">
			
			 <li><a href="product_list"><i class="zmdi zmdi-dot-circle-alt"></i>Add</a></li>
			 <li><a href="list"><i class="zmdi zmdi-dot-circle-alt"></i>Category</a></li>
			 <!-- <li><a href="add_stock"><i class="zmdi zmdi-dot-circle-alt"></i>Add Stock</a></li>
			 <li><a href="purchases"><i class="zmdi zmdi-dot-circle-alt"></i>Records</a></li>
			<li><a href="inventory"><i class="zmdi zmdi-dot-circle-alt"></i>Stock</a></li>
			<li><a href="order_lists"><i class="zmdi zmdi-dot-circle-alt"></i>Requisitions</a></li>
			<li><a href="invoice_list"><i class="zmdi zmdi-dot-circle-alt"></i>Adjustments</a></li> -->
		 </ul>
	 </li>

 
  <li><a href="settings" class="waves-effect"><i class="zmdi zmdi-settings"></i> <span>Add Vehicle</span></a></li>
 </ul>

</div>
<!--End sidebar-wrapper-->
