<?php

include_once "../connect.php"; // database connection details stored here

if (isset($_POST['register'])){
    $made   = $_POST["made"];
     $ref   = $_POST["ref"];
        $t   = $_POST["type"][$i];
         $name   = $_POST["name"];
        $qty    = $_POST["qty"];
        $code=substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 15);
        $query  = "INSERT INTO product_list (name,ref, qty,company,code,type) VALUES ('$name','$ref','$qty','$made','$code','$t')";
        $result = mysqli_query($con, $query);

       

    

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Medicine List</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

	<!--Data Tables -->
<link href="../assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="../assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

<!--Select Plugins-->
  <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet"/>
  <!--inputtags-->
  <link href="../assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />
  <!--multi select-->
  <link href="../assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
  <!--Bootstrap Datepicker-->
  <link href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
  <!--Touchspin-->
  <link href="../assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css">

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Medicine List</h4>

	   </div>
     </div>
    <!-- End Breadcrumb-->
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">

			<form role="form" method="post" enctype="multipart/form-data" action=""  onsubmit="return validate()">
              <h4 class="form-header text-uppercase">
                <i class="fa fa-address-book-o"></i>
                  Fill the form below
              </h4>

              <div class="form-group row">
                <label for="input-14" class="col-sm-2 col-form-label">Type</label>
                  <div class="col-sm-4">
                    
                    <select name="type" class="form-control single-select"  required>
                    <option value="" >Select Category/ Type</option>
                    <?php
                               $result = $con->query("SELECT  name FROM list  ORDER BY name ASC");
                                while ($row = $result->fetch_assoc()) {
                                    unset($id, $name);
                                
                               $name = $row['name']; 
                               echo '<option value="'.$name.'">'.$name.'</option>';
                               }
                             ?>
                          
                   
                  </select>
                  </div>

                  <label for="input-10" class="col-sm-2 col-form-label">Item Name </label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" id="input-10" name="name" >
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-14" class="col-sm-2 col-form-label">Made in (Country)</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" name="made">
                    
                  </div>
                  <label for="input-15" class="col-sm-2 col-form-label">Trucks</label>
                  <div class="col-sm-4">
                    <select name="ref" class="form-control single-select"  required>
                    <option value="" >Select Trucks</option>
                    <?php
                               $result = $con->query("SELECT  t_name,ref FROM transporter  ORDER BY t_name ASC");
                                while ($row = $result->fetch_assoc()) {
                                    unset($id, $name);
                                 $eid = $row['ref'];
                               $name = $row['t_name']; 
                               echo '<option value="'.$eid.'">'.$eid.' '.$name.'</option>';
                               }
                             ?>
                          
                    <option>Others</option>
                  </select>
                  </div>
  								

  							</div>


              <div class="form-group row">
                <label for="input-11" class="col-sm-2 col-form-label">Code</label>
                <div class="col-sm-4">
                  <?php $sample=substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 15); ?>
                  <input type="text"  name="code"  class="form-control" value="<?php echo $sample; ?> "  readonly>
                </div>
              <label for="input-12" class="col-sm-2 col-form-label">Quantity</label>
              <div class="col-sm-4">
                <input type="number" name="qty"  class="form-control">
              </div>
              </div>


              

							<div class="form-group row">
                
		          </div>




              <div class="form-footer">
                  <button type="submit" name="register"  class="btn btn-success"><i class="fa fa-check-square-o"></i> Register</button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div><!--End Row-->

		<div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Medicine List</div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                    <tr>
                      <th>#</th>
                        												
                        <th>Transporter</th>
                        <th>Item </th>
                        <th>Quantity</th>
                        <th>Manufacturin Country</th>
                       
                        
												<th>Delete</th>
                    </tr>
                </thead>
								<tbody>
			            <?php
                  $i=0;
			            $query=mysqli_query($con, "SELECT *  FROM `product_list` ORDER BY ref DESC")or die(mysqli_error());
			            while($row=mysqli_fetch_array($query)){
                    $i=$i+1;
			            ?>
			            <tr>
                    <td><?php echo $i; ?></td>
                  <td><?php echo $row['ref']; ?></td>
                  <td><?php echo $row['name']; ?></td>
                  <td><?php echo $row['qty']; ?></td>
                  <td><?php echo $row['company']; ?></td>
                 
			           <td><a href="delete_product?id=<?php echo $row['sno']; ?>"><input type='submit'  type='submit' onClick="return confirm('Are you sure you want to Delete?');" class="btn btn-danger delete" value='Delete'>	</a></td>

			            </tr>
			            <?php } ?>
			          </tbody>

            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>
<?php  include_once("footer-data.php"); ?>