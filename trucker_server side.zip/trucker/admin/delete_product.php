<?php
	include_once('../connect.php');
	$id=$_GET['id'];
	$result = $dbo->prepare("DELETE FROM product_list WHERE sno= :id");
	$result->bindParam(':id', $id);
	$result->execute();
	header('location:product_list');
?>
