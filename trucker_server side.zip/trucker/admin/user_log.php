<?php

include "../connect.php"; // database connection details stored here

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | User Log</title>
  <!--favicon-->
    <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">

    <!--Select Plugins-->
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet"/>
    <!--inputtags-->
    <link href="../assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />
    <!--multi select-->
    <link href="../assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
    <!--Bootstrap Datepicker-->
    <link href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
    <!--Touchspin-->
    <link href="../assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css">

    <!-- simplebar CSS-->
    <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
    <!-- Bootstrap core CSS-->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- animate CSS-->
    <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
    <!-- Icons CSS-->
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
    <!-- Sidebar CSS-->
    <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
    <!-- Custom Style-->
    <link href="../assets/css/app-style.css" rel="stylesheet"/>

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">User Log</h4>

	   </div>

     </div>
    <!-- End Breadcrumb-->

     <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">

<label>Choose Date Range</label>
<form action="user_log.php" method="get">
<div id="dateragne-picker">
                <div class="input-daterange input-group">
                 <input type="text" class="form-control" name="start"    dateFormat="yyy-mm-dd" autocomplete="off"/>
                 <div class="input-group-prepend">
                  <span class="input-group-text">to</span>
                 </div>
                 <input type="text" class="form-control" name="end" autocomplete="off"/>
                </div>

              </div>
<hr>
<button class="btn btn-success" name = "submit">Search</button>
</form>


<div style="font-weight:bold; text-align:center;font-size:14px;margin-bottom: 15px;">
User Log from&nbsp;<?php echo $_GET['start'] ?>&nbsp;to&nbsp;<?php echo $_GET['end'] ?>
</div>


<table class="table table-bordered table-striped" id="table_example" data-responsive="table" >
<thead>
<tr>
  <th> Date </th>
  <th> Time </th>
  <th> User </th>
  <th> IP Address </th>


</tr>
</thead>
<tbody>

  <?php



    $start_date =  $_GET['start'];


    $end_date =    $_GET['end'];

    $result = $dbo->prepare("select mytime,DATE(log_date) AS mydate, message, remote_addr FROM `my_log` WHERE DATE(log_date) BETWEEN '" . $start_date . "' AND '" . $end_date . "' ORDER BY log_id DESC ");

    $result->execute();
    for($i=0; $row = $result->fetch(); $i++){

  ?>

  <tr class="record">

        <td><?php echo $row['mydate']; ?></td>
        <td><?php echo $row['mytime']; ?></td>
        <td><?php echo $row['message']; ?></td>
        <td><?php echo $row['remote_addr']; ?></td>


  </tr>
  <?php
    }
  ?>

</tbody>

</table>
            </div>
            </div>
          </div>
        </div>
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>

<?php  include_once("footer-data.php"); ?>
