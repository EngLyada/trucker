<?php

include_once "../connect.php"; // database connection details stored here
mysqli_query($con,"DELETE FROM  optional ") or die(mysql_error());
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Product List</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

	<!--Data Tables -->
<link href="../assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="../assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">

<!--Select Plugins-->
  <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet"/>
  <!--inputtags-->
  <link href="../assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />
  <!--multi select-->
  <link href="../assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
  <!--Bootstrap Datepicker-->
  <link href="../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
  <!--Touchspin-->
  <link href="../assets/plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css">

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Product List</h4>

	   </div>
     </div>
    <!-- End Breadcrumb-->
<div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Products List</div>
            <div class="card-body">
              <div class="table-responsive">
              <form action="pdt_saven" method="post">

                                      <br>
                                    <button class="btn btn-success pull-right" name="submit_mult" type="submit">Add Selected</button>

                               <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th><input id="check_all1" class="formcontrol" type="checkbox"/></th>
                        <th>Code</th>
                        <th>Item Description</th>
                        <th>Shop Location</th>
												<th>Image</th>

                    </tr>
                </thead>
								<tbody>
			            <?php

			            $query=mysqli_query($con, "SELECT *  FROM `product_list` ORDER BY sno DESC ")or die(mysqli_error());
			            while($row=mysqli_fetch_array($query)){
                      $id=$row['sno'];
			            ?>
			            <tr>
                  <td><input name="selector[]" class="case" onchange="test(this.value)" type="checkbox" value="<?php echo $id; ?>"></td>
                  <td><?php echo $id ?></td>
                  <td><?php echo $row['cat']. ' ' .$row['name']. ' ' .$row['brand']. ' ' .$row['vehicle']. ' ' .$row['engine']. ' ' .$row['chasis']. ' ' .$row['partNo'] ; ?></td>
                  <td><?php echo $row['shop_point']?></td>
                  <td>
                    <?php

                    $img = $row['user_image'];

                    if ($row['user_image'] == ''){

                      echo "<img src='../assets/images/umagi.jpg'  width='150'/>";
                    }
                    else {

                      echo "<img src='../assets/images/$img'  width='150' />";
                    }

                    ?>
                  </td>
                  </tr>
			            <?php } ?>
			          </tbody>

            </table>
            <div class='row'>
                <div class='col-xs-12 col-sm-3 col-md-3 col-lg-3'>
            <br>
          <button class="btn btn-success pull-right" name="submit_mult" type="submit">Add Selected</button>
        </form>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>
<?php  include_once("footer-data.php"); ?>
<script type="text/javascript">

 function test(value) {

     if (window.XMLHttpRequest) {
                        xmlhttp = new XMLHttpRequest();
                    }

           xmlhttp.open("GET", "add_to_list.php?pid=" + value, true);
           xmlhttp.send();

         return false;
 }
</script>
