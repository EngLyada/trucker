<?php

include "../connect.php"; // database connection details stored here


if (isset($_POST['register'])){
		$name			= $_POST['name'];
		$type			= $_POST['type'];

    $check = mysqli_query($con, "SELECT * FROM list WHERE name='$name'")or die(mysqli_error());


		if (mysqli_num_rows($check) > 0) {
  	  $name_error = "Sorry... name already exists";
  	}else
      mysqli_query($con, "insert into list (name,type) values('$name','$type')")or die(mysqli_error());
		}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | List</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Quick Add</h4>

	   </div>

     </div>
    <!-- End Breadcrumb-->
    <div class="row">
   <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        <div class="card-title">Medicine Category</div>
        <hr>
         <form role="form" method="post" enctype="multipart/form-data" action="list"  onsubmit="return validate()">
        <div class="form-group">
         <label for="input-1">Name</label>
         <input type="text" name = "name" class="form-control" id="input-1" placeholder="Enter Car Name">
				 <?php if (isset($name_error)): ?>
	  	<span><?php echo $name_error; ?></span>
	  <?php endif ?>
         <input type="hidden" name = "type"  value = "car">
        </div>

        <div class="form-group">
         <button type="submit" name="register"  class="btn btn-light px-5"><i class="icon-lock"></i> Register</button>
       </div>
       </form>
      </div>
      </div>



       <table id="example" class="table table-bordered">
         <thead>
             <tr>
                 <th>Name</th>
                 <th>Delete</th>
             </tr>
         </thead>
         <tbody>
           <?php

           $query=mysqli_query($con, "SELECT *  FROM `list` WHERE type = 'car' ORDER BY name ASC")or die(mysqli_error());
           while($row=mysqli_fetch_array($query)){
           ?>
           <tr>
           <td><?php echo $row['name']; ?></td>
          <td><a href="delete_list?id=<?php echo $row['id']; ?>"><input type='submit'  type='submit' onClick="return confirm('Are you sure you want to Delete?');" class="btn btn-danger delete" value='Delete'>	</a></td>

           </tr>
           <?php } ?>
         </tbody>

     </table>


   </div>

   

 </div><!--End Row-->

<?php  include_once("footer.php"); ?>
