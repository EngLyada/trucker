<?Php
require "../connect.php";// Database connection

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Dashboard</title>
  <!--favicon-->
   <link rel="icon" href="../assets/images/logo.png" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/popper.min.js"></script>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
    
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Weight');
        data.addColumn('number', 'Traveling Date Time');
        for(i = 0; i < my_2d.length; i++)
    data.addRow([my_2d[i][0], parseInt(my_2d[i][1])]);
       var options = {
          title: 'A graph of Weight against Date Time',
        curveType: 'function',
    width: 1800,
        height: 900,
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);
       }
  ///////////////////////////////
</script>
  

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>

<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

<div class="content-wrapper">
  <div class="container-fluid">

<div class="row mt-3">
  <div class="col-12 col-lg-6 col-xl-6">
    <div class="card">
    <div class="card-body">
        <p class="text-white mb-0">Transporter <span class="float-right badge badge-light">Annual <?php echo date('Y');?></span></p>
         <div class="">
         <h4 class="mb-0 py-3">

           <?php
           $result = $dbo->prepare("SELECT * FROM transporter ");
            $result->execute();
            $rowcount = $result->rowcount();
             echo $rowcount;
            ?>
           <span class="float-right"><i class="fa fa-home"></i></span></h4>
         </div>
         <div class="progress-wrapper">
          <div class="progress" style="height:5px;">
          <div class="progress-bar" style="width:60%"></div>
           </div>
        </div>
      </div>
    </div>
   </div>


   <div class="col-12 col-lg-6 col-xl-6">
    <div class="card">
    <div class="card-body">
        <p class="text-white mb-0">Products <span class="float-right badge badge-light"></span></p>
         <div class="">
         <h4 class="mb-0 py-3">

           <?php
           $result = $dbo->prepare("SELECT * FROM product_list ");
            $result->execute();
            $rowcount = $result->rowcount();
             echo $rowcount;
            ?>

            <span class="float-right"><i class="fa fa-search"></i></span></h4>
         </div>
         <div class="progress-wrapper">
          <div class="progress" style="height:5px;">
          <div class="progress-bar" style="width:80%"></div>
           </div>
        </div>
        </div>
    </div>
   </div>
  
   </div>
 <div class="col-12 col-lg-12 col-xl-12">
    <div class="card">
    <div class="card-body">
        


            <div class="card-body">

            <form role="form" method="post" enctype="multipart/form-data" action=""  onsubmit="return validate()">
              <h4 class="form-header text-uppercase">
                <i class="fa fa-address-book-o"></i>
                  Tamper proof product Ditection
              </h4>

              

                <div class="form-group row">
                 
                  <label for="input-15" class="col-sm-2 col-form-label">Select Truck</label>
                  <div class="col-sm-9">
                    <select name="ref" class="form-control single-select"  required>
                    <option value="" >Select Category</option>
                    <?php
                               $result = $con->query("SELECT  t_name,ref FROM transporter  ORDER BY t_name ASC");
                                while ($row = $result->fetch_assoc()) {
                                    unset($id, $name);
                                 $eid = $row['ref'];
                               $name = $row['t_name']; 
                               echo '<option value="'.$eid.'">'.$eid.' '.$name.'</option>';
                               }
                             ?>
                          
                    <option>Others</option>
                  </select>
                  </div>
                <div class="col-sm-1">
                     <button type="submit" name="register"  class="btn btn-success"><i class="fa fa-check-square-o"></i> Continue</button>
                    
                  </div>        

            </div>

            </form>
              
          </div>

         <div class="card-body">
            <div class="form-group row">
              
                  <div class="col-sm-9">
                      <?php if (isset($_POST['register'])) {
                // code...
                if($stmt = $con->query("SELECT date,weight FROM test_results")){

                  // echo "No of records : ".$stmt->num_rows."<br>";
                $php_data_array = Array(); // create PHP array
                //   echo "<table>
                // <tr> <th>Month</th><th>Sale</th><th>Profit</th><th>Exp Fxd</th><th>Exp Vrv</th></tr>";
                while ($row = $stmt->fetch_row()) {
                   // echo "<tr><td>$row[0]</td><td>$row[1]</td></tr>";
                   $php_data_array[] = $row; // Adding to array
                   }
                // echo "</table>";
                }else{
                echo $connection->error;
                }
                //print_r( $php_data_array);
                // You can display the json_encode output here. 
                //echo json_encode($php_data_array); 

                // Transfor PHP array to JavaScript two dimensional array 
                echo "<script>
                        var my_2d = ".json_encode($php_data_array)."
                </script>";
            } ?>
              <div id="curve_chart"></div>
                  </div>
            </div>

            
         </div>
         <div class="progress-wrapper">
          <div class="progress" style="height:5px;">
          
           </div>
        </div>
        </div>
    </div>
   </div>
 </div><!--End Row-->

  

     
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  </div>
</div>
<?php  include_once("footer.php"); ?>