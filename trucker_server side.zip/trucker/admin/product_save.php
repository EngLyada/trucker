<?php
// configuration
include_once('../connect.php');

if (isset($_POST['register'])){
		
		$ref			= $_POST['ref'];
		
		$org		=	$_POST['organ'];
		$ori			=	$_POST['origin'];
		$dest				=	$_POST['destn'];
		$tn		=	$_POST['t_name'];
		$tt		=	$_POST['t_tel'];
		$sup		  =	$_POST['supervisor'];
		
		$cat			=	$_POST['cat'];
		$nin			=	$_POST['nin'];

          $size=count($_POST["name"]);

         


		mysqli_query($con, "insert into transporter (organization, origin, destn, t_name, t_tel, supervisor, category,nin,ref) values('$org','$ori','$dest','$tn','$tt','$sup','$cat','$nin','$ref')")or die(mysqli_error());

		

		}

header("location: settings");

?>
