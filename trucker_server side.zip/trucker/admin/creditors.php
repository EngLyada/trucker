<?php

include "../connect.php"; // database connection details stored here

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Creditors</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

</head>


<?php include_once("top-bar.php"); ?>

<?php include_once("sidebar.php"); ?>


<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Creditors Summary</h4>

	   </div>

     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <table class="table table-bordered table-striped" id="table_example" data-responsive="table" >
    					<thead>
    						<tr>
                <th>Customer</th>
    						<th>Invoice Total</th>
    						<th>Amount Paid</th>
    						<th>Balance</th>
                <th>Payments</th>
                <th>Statement</th>
                <th>History</th>
    						</tr>
    					</thead>


    					<tbody>
    						<?php
    						$query=mysqli_query($con, "SELECT
    	m.customer,
      m.date,
    	m.total,
    	s.paid
    	FROM (SELECT p.date, p.customer, SUM(i.price *  i.quantity) total FROM sh_sales_details AS p INNER JOIN sh_sales_list AS i
    	ON p.id = i.invoice WHERE cash = 'No' GROUP BY customer) m
    	LEFT JOIN
    	(SELECT cust, SUM(paid) paid FROM credit_pay GROUP BY cust) s
    	ON m.customer = s.cust
    GROUP BY customer ORDER BY customer ASC")or die(mysqli_error());
    						while($row=mysqli_fetch_array($query)){
    							$tm = number_format ($row['total']);
    							$tp = number_format ($row['paid']);

    							$bal = $row['total'] - $row['paid'];

    						?>
    						<tr>
    						<td><?php echo $row['customer']; ?></td>
    						<td><?php echo $tm; ?>
    						<td><?php echo $tp; ?>
    						<td><?php echo number_format ($bal); ?></td>
                <td><form  method="post" action="credit_payment?customer=<?php echo $row['customer']; ?>"><input type='submit'  class="btn btn-success addmore" value='Payment'>	</form></td>
                <td><form  method="post" action="credit_aging?customer=<?php echo $row['customer']; ?>"><input type='submit'  class="btn btn-primary" value='View'>	</form></td>
                <td><form  method="post" action="credit_history?customer=<?php echo $row['customer']; ?>"><input type='submit'  class="btn btn-info" value='View'>	</form></td>
    						</td>
    						</tr>
    						<?php } ?>
    					</tbody>
    					<thead>
    		<tr>
    			<th colspan="1"> Total: </th>
    			<th colspan="1">
    			<?php
    				 $query=mysqli_query($con, "SELECT SUM(i.price *  i.quantity) total  FROM sh_sales_details AS p INNER JOIN
                        sh_sales_list AS i ON p.id = i.invoice WHERE cash = 'No' ")or die(mysqli_error());
    						while($row=mysqli_fetch_array($query)){

    							$total = $row['total'];

    							echo number_format ($total);

    				?>

    			</th>

    			<th colspan="1">
    			<?php
    				 $query=mysqli_query($con, "SELECT p.customer, SUM(s.paid) paid FROM sh_sales_details AS p
                                                LEFT JOIN credit_pay AS s ON p.id = s.t_id WHERE cash = 'No' ")or die(mysqli_error());
    						while($row=mysqli_fetch_array($query)){

    							$paid = $row['paid'];

    							echo number_format ($paid);

    				?>

    			</th>

    				<th colspan="1">
    			<?php
    			      $pending = $total - $paid ;

    							echo number_format ($pending);
    			}
    				}
    				?>
    				</th>
    		</tr>
    	</thead>
    				</table>
        </div>
      </div>
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>

<?php  include_once("footer.php"); ?>
