<?php

include "../connect.php"; // database connection details stored here

if (isset($_POST['register'])){
				$name						= $_POST['name'];
				$address				= $_POST['address'];
				$phone					=	$_POST['phone'];
				$contact_person	=	$_POST['contact_person'];
				$notes					=	$_POST['notes'];
				$branch					=	$_POST['branch'];

				$check = mysqli_query($con, "SELECT * FROM customer WHERE name='$name'")or die(mysqli_error());

				if (mysqli_num_rows($check) > 0) {
					$name_error = "Sorry... name already exists";
				}else
					mysqli_query($con, "insert into customer (name,address,phone,contact,notes,branch) values('$name','$address','$phone','$contact_person','$notes','$branch')")or die(mysqli_error());
				}
			
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $name ?> | Customers</title>
  <!--favicon-->
  <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="../assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="../assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="../assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="../assets/css/app-style.css" rel="stylesheet"/>

</head>


<?php include_once("top-bar.php"); ?>
<?php include_once("sidebar.php"); ?>
<?php  include_once("header.php"); ?>

<div class="clearfix"></div>

  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Customers</h4>

	   </div>

     </div>
    <!-- End Breadcrumb-->
    <div class="row">
    <div class="col-lg-12">

       <div class="card">
         <div class="card-body">
         <div class="card-title">All Fields are required</div>
         <hr>
           <form role="form" method="post" enctype="multipart/form-data" action="customers"  onsubmit="return validate()">
         <div class="form-group row">
          <label for="input-21" class="col-sm-2 col-form-label">Customer Name</label>
          <div class="col-sm-10">
        <input type="text"  name="name" class="form-control" id="skills" placeholder="Enter Name" required>
          </div>
        </div>
        <div class="form-group row">
        <label for="input-25" class="col-sm-2 col-form-label">Address</label>
        <div class="col-sm-10">
        <input type="text"  name="address"  class="form-control"  required>
        </div>
        </div>
        <div class="form-group row">
          <label for="input-22" class="col-sm-2 col-form-label">Phone No.</label>
          <div class="col-sm-10">
          <input type="text"  name="phone"  class="form-control" id="exampleInputEmail1"  placeholder="Enter Phone No." required>
          </div>
        </div>
        <div class="form-group row">
          <label for="input-24" class="col-sm-2 col-form-label">Currency</label>
          <div class="col-sm-10">

					<select name="contact_person" class="form-control">
										<option>UGX</option>
										<option>USD</option>
					</select>
          </div>
        </div>
          <div class="form-group row">
          <label for="input-23" class="col-sm-2 col-form-label">Credit Limit</label>
          <div class="col-sm-10">
           <input type="text"  name="notes" class="form-control" id="skills" placeholder="Enter Credit Limit" >
          </div>
          </div>

					<input type="hidden"  name="branch" class="form-control" id="skills" value="Main" >

         <div class="form-group row">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
          <button type="submit" name="register" class="btn btn-primary"><i class="icon-lock"></i> Register</button>
          </div>
        </div>
        </form>
       </div>
     </div>

     <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">All Customers</h5>
			  <div class="table-responsive">
               <table class="table table-striped">
                 <thead>
           <tr>
             <th>Customer Name</th>
   						<th>Address</th>
   						<th>Phone No.</th>
   						<th>Currency</th>
   						<th>Credit Limit</th>
   						<th>Edit</th>
   						<th>Delete</th>
           </tr>
         </thead>
         <tbody>
           <?php
           $query=mysqli_query($con, "SELECT *  FROM `customer`  ORDER BY name ASC")or die(mysqli_error());
           while($row=mysqli_fetch_array($query)){
           ?>
           <tr>
             <td><?php echo $row[1]; ?></td>
  						<td><?php echo $row[2]; ?></td>
  						<td><?php echo $row[3]; ?></td>
							<td><?php echo $row[5]; ?></td>
  						<td><?php
							if ($row[4] != ''){
								echo number_format($row[4]);
							}else{
								echo '';
							}?></td>
  						<td><a href="customer_edit?id=<?php echo $row['id']; ?>"><input type='submit' class="btn btn-success addmore" value='Edit'>	</a></td>
  						<td><a href="delete_customer?id=<?php echo $row['id']; ?>"><input type='submit'  type='submit' onClick="return confirm('Are you sure you want to Delete?');" class="btn btn-danger delete" value='Delete'>	<a/></td>
           </tr>
           <?php } ?>
         </tbody>
       </table>
            </div>
            </div>
          </div>
        </div>
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
  </div>
</div>
<?php  include_once("footer.php"); ?>
