<?php
// database connection details stored here

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include "connect.php"; 
$list="";
$username= $_POST["username"];
  $query="select * from product_list where code='$username'";

        $result=mysqli_query($con,$query);
    if(mysqli_num_rows($result)>0)
      {
             while($row=mysqli_fetch_array($result))
            {
              if($list=="")
                 {
               
                  $id=$row['sno'];
                  $name=$row['name'];
                  $ref=$row['ref'];
                  $qty=$row['qty'];
                 }


             }
       }

       if(mysqli_num_rows($result)==0)
       {
           $response["success"] = "0";
            $response["message"]="Fake product| UNKNOWN";
             echo json_encode($response);
              mysqli_close($con);
       }
       else
          {
                         //response to android app
              $response["success"]="1";
                          $response["message"]="Logged in successful";
                      $response["sno"]=$id;
                          $response["name"]=$name;
                          $response["ref"]=$ref;
                          $response["qty"]=$qty;
                          //converting response data into json format
              echo json_encode($response);
               mysqli_close($con);
     }

?>