<?Php
class data_pass{
	public $link='';
	function __construct($ref,$date,$weight,$longitude,$latitude){
		$this->connect();
		$this->storeInDB($ref,$date,$weight,$longitude,$latitude);
	}

	function connect(){
		$this->link = mysqli_connect('localhost','u829526653_truckeradmin','Kmbeatrice@12') or die('Cannot connect to the DB');
		mysqli_select_db($this->link,'u829526653_trucker')or die('Cannot Select to the DB');
		
	}
	function storeInDB($ref,$date,$weight,$longitude,$latitude){
		$query="INSERT INTO test_results SET ref='" .$ref."',date='".$date."',weight='".$weight."',longitude='".$longitude."',latitude='".$latitude."'";
		$result = mysqli_query($this->link,$query)or die('Error Query: '.$query);
		echo "Data successfully saved";

	}
}
if($_GET['ref']!='' and $_GET['date']!='' and $_GET['weight']!='' and $_GET['longitude']!='' and $_GET['latitude']!=''){
	$data_pass=new data_pass($_GET['ref'],$_GET['date'],$_GET['weight'],$_GET['longitude'],$_GET['latitude']);
}
?>